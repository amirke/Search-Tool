=== SEARCH TOOL - PORTABLE VERSION ===

🚀 NO INSTALLATION REQUIRED - RUN DIRECTLY! 🚀

This is a PORTABLE version that bypasses Windows SmartScreen warnings.

📋 FIRST TIME SETUP:
1. If WebView2 is not installed, run: WebView2Installer.exe
2. Double-click: "Search Tool.exe" to start

✅ FEATURES:
- No installation required
- No registry changes
- No administrator privileges needed
- Runs from any folder
- No Windows Defender SmartScreen warnings
- Expand/Collapse toggle button (NEW!)
- Results expanded by default (NEW!)
- Updated UI improvements (NEW!)

🔧 REQUIREMENTS:
- Windows 10/11
- Microsoft Edge WebView2 (included installer: WebView2Installer.exe)

📝 FILES INCLUDED:
- Search Tool.exe (Main application - UPDATED with latest changes)
- rg.exe (Ripgrep search engine)
- WebView2Installer.exe (WebView2 runtime)
- README.txt (This file)
- First-Run.bat (Automated setup)

🆕 LATEST UPDATES:
- Fixed expand/collapse functionality
- Button replaces checkbox for better UX
- Results show expanded by default
- All dev improvements included
- Fresh build with latest source code

🌟 ENJOY SAFE AND FAST TEXT SEARCHING! 🌟